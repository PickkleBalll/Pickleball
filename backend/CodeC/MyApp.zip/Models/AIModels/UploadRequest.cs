﻿namespace PickleballVideoAnalyzer.Models
{
   public class UploadRequest
   {
       public IFormFile Video { get; set; }
   }
}

﻿//using System;

//namespace coach.Models
//{
//    public class PaymenT
//    {
//        public string Id { get; set; }
//        public int CoachId { get; set; }
//        public string StudentName { get; set; }
//        public decimal Amount { get; set; }
//        public DateTime PaidAt { get; set; }
//        public string Method { get; set; }
//    }
//}
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using MyApp.Data;
//using MyApp.Models;

//namespace MyApp.Controllers.admin_login
//{
//    [ApiController]
//    [Route("api/admin/materials")]
//    [Authorize(Roles = "Admin")]
//    public class AdminMaterialController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        public AdminMaterialController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

//        // Cac action giu nguyen nhu cu...
//    }
//}

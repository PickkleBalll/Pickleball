﻿namespace MyApp.Dto
{
    public class CreateCoachRequestDto
    {
        public string LearnerId { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
    }
}

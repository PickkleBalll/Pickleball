﻿namespace MyApp.Dto
{
   public class AnalyzeVideoRequest
   {
       public IFormFile Video { get; set; } = default!;
   }
}
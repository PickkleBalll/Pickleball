﻿namespace MyApp.Dto
{
    public class RegisterCourseDto
    {
        public string LearnerId { get; set; } = default!;
        public string CourseId { get; set; } = default!;
    }
}
